Kelompok 2
- 00000080773 - Genadi Ikhsan Jaya
- 00000080948 - Malvin Wijaya
- 00000082784 - Rachelle Stephanie Rianto
- 00000083222 - Anastasia Sidebang

Link GitHub : https://github.com/rachellestephanie/UTS-PTI-Kelompok-2.git